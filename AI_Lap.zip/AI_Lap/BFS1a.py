from queue import Queue

# Define a graph
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F', 'G'],
    'D': [],
    'E': ['H'],
    'F': [],
    'G': ['I'],
    'H': [],
    'I': []
}


def bfs(graph, start):
    visited = set()  # Set to keep track of visited nodes
    queue = Queue()  # Initialize a queue
    visited.add(start)
    queue.put(start)

    while not queue.empty():
        # Dequeue a vertex from queue and print it
        vertex = queue.get()
        print(vertex, end=" ")

        # Get all adjacent vertices of the dequeued vertex s
        # If an adjacent has not been visited, then mark it
        # visited and enqueue it
        for neighbour in graph[vertex]:
            if neighbour not in visited:
                visited.add(neighbour)
                queue.put(neighbour)


# Driver code
bfs(graph, 'A')
