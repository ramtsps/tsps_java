from queue import PriorityQueue

# Define a graph
graph = {
    'A': {'B': 2, 'C': 3},
    'B': {'D': 4, 'E': 5},
    'C': {'F': 6, 'G': 7},
    'D': {},
    'E': {'H': 8},
    'F': {},
    'G': {'I': 9},
    'H': {},
    'I': {}
}

# Define heuristic function
heuristic = {
    'A': 10,
    'B': 8,
    'C': 7,
    'D': 6,
    'E': 5,
    'F': 3,
    'G': 2,
    'H': 1,
    'I': 0
}


def astar(graph, heuristic, start, goal):
    queue = PriorityQueue()
    queue.put((0, start))
    visited = set()

    while not queue.empty():
        (cost, current_node) = queue.get()

        if current_node == goal:
            return cost

        if current_node in visited:
            continue

        visited.add(current_node)

        for neighbour, neighbour_cost in graph[current_node].items():
            neighbour_cost_total = neighbour_cost + heuristic[neighbour]
            queue.put((cost + neighbour_cost_total, neighbour))

    return -1  # if goal is not reachable


# Driver code
cost = astar(graph, heuristic, 'A', 'I')
print(cost)
