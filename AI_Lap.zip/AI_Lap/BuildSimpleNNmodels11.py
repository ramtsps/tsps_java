import numpy as np
from keras.models import Sequential
from keras.layers import Dense

# Create some random data
x_train = np.random.random((1000, 10))
y_train = np.random.randint(2, size=(1000, 1))

# Define the model
model = Sequential()
model.add(Dense(64, input_dim=10, activation='relu'))
model.add(Dense(32, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# Compile the model
model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

# Train the model
model.fit(x_train, y_train, epochs=10, batch_size=32)

# Test the model
x_test = np.random.random((100, 10))
y_test = np.random.randint(2, size=(100, 1))
score = model.evaluate(x_test, y_test, batch_size=32)
print("Test loss:", score[0])
print("Test accuracy:", score[1])
