import numpy as np
from pgmpy.models import BayesianModel


class BayesianNetworkEM:
    def __init__(self, bn: BayesianModel):
        self.bn = bn
        self.params = self.initialize_params()

    def initialize_params(self):
        params = {}
        for node in self.bn.nodes():
            parents = list(self.bn.predecessors(node))
            num_states = self.bn.get_cardinality(node)
            parent_states = [self.bn.get_cardinality(parent) for parent in parents]
            if len(parents) == 0:
                params[node] = np.random.rand(num_states)
            else:
                params[node] = np.random.rand(np.prod(parent_states), num_states)
        return params

    def e_step(self, data):
        n_samples = data.shape[0]
        n_states = np.array([self.bn._node[var]['num_states'] for var in self.bn.nodes()])
        joint_prob = np.ones((n_samples, np.prod(n_states)))
        for node in self.bn.nodes():
            parents = self.bn.predecessors(node)
            if len(parents) == 0:
                node_prob = self.params[node]
            else:
                parent_states = np.array([self.bn._node[parent]['num_states'] for parent in parents])
                parent_idxs = np.dot(data[:, parents], np.cumprod(np.hstack((1, parent_states[:-1]))))
                node_prob = self.params[node][parent_idxs]
            joint_prob *= node_prob
        joint_prob /= np.sum(joint_prob, axis=1, keepdims=True)
        return joint_prob

    def m_step(self, data, joint_prob):
        n_samples = data.shape[0]
        for node in self.bn.nodes():
            parents = list(self.bn.predecessors(node))
            if len(parents) == 0:
                self.params[node] = np.sum(joint_prob[:, node], axis=0) / n_samples
            else:
                parent_states = [self.bn.get_cardinality(parent) for parent in parents]
                parent_idxs = np.dot(data[:, parents], np.cumprod(np.hstack((1, parent_states[:-1]))))
                parent_prob = np.zeros((np.prod(parent_states), self.bn.get_cardinality(node)))
                for i in range(n_samples):
                    parent_prob[parent_idxs[i]] += joint_prob[i, node]
                parent_prob /= np.sum(parent_prob, axis=1, keepdims=True)
                self.params[node] = parent_prob

    def fit(self, data, max_iter=100, tol=1e-6):
        log_likelihood = -np.inf
        for i in range(max_iter):
            joint_prob = self.e_step(data)
            self.m_step(data, joint_prob)
            new_log_likelihood = np.sum(np.log(np.sum(joint_prob, axis=1)))
            if np.abs(new_log_likelihood - log_likelihood) < tol:
                break
            log_likelihood = new_log_likelihood
        return self.params


bn = BayesianModel([('A', 'C'), ('B', 'C'), ('C', 'D')])
bn.add_nodes_from(['E', 'F'])
bn.add_edges_from([('A', 'F'), ('B', 'E')])

# print the structure of the BayesianModel
print("Nodes: ", bn.nodes())
print("Edges: ", bn.edges())

# print the CPDs of each node
for node in bn.nodes():
    cpd = bn.get_cpds(node)
    print("Node: ", node)
    print(cpd)
