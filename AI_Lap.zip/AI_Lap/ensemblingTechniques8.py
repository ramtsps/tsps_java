from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier, AdaBoostClassifier, StackingClassifier, VotingClassifier

# Load the iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Create a decision tree classifier
tree = DecisionTreeClassifier()

# Create a bagging classifier
bagging = BaggingClassifier(base_estimator=tree, n_estimators=10)

# Create an AdaBoost classifier
adaboost = AdaBoostClassifier(base_estimator=tree, n_estimators=10)

# Create a stacking classifier
stacking = StackingClassifier(estimators=[('bagging', bagging), ('adaboost', adaboost)], final_estimator=tree)

# Create a voting classifier
voting = VotingClassifier(estimators=[('bagging', bagging), ('adaboost', adaboost), ('stacking', stacking)])

# Train the models on the training set
tree.fit(X_train, y_train)
bagging.fit(X_train, y_train)
adaboost.fit(X_train, y_train)
stacking.fit(X_train, y_train)
voting.fit(X_train, y_train)

# Evaluate the models on the testing set
print("Decision Tree Accuracy: ", tree.score(X_test, y_test))
print("Bagging Accuracy: ", bagging.score(X_test, y_test))
print("AdaBoost Accuracy: ", adaboost.score(X_test, y_test))
print("Stacking Accuracy: ", stacking.score(X_test, y_test))
print("Voting Accuracy: ", voting.score(X_test, y_test))
