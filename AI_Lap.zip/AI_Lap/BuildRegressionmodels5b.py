import tensorflow as tf
import pandas as pd

# Load the dataset
data = pd.read_csv('data.csv')

# Split the dataset into features and target
X = data[['x']].values
y = data['y'].values

# Define the neural network model
model = tf.keras.Sequential([
    tf.keras.layers.Dense(units=10, activation='relu', input_shape=(1,)),
    tf.keras.layers.Dense(units=1)
])

# Compile the model
model.compile(optimizer=tf.optimizers.Adam(learning_rate=0.1), loss='mean_squared_error')

# Train the model
model.fit(X, y, epochs=50, batch_size=32)

# Make predictions on new data
new_data = pd.DataFrame({'x': [0.1, 0.2, 0.3]})
predictions = model.predict(new_data)

print(predictions)
