from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
import matplotlib.pyplot as plt

# Generate some random data
X, y = make_blobs(n_samples=500, centers=5, random_state=42)

# Plot the data
plt.scatter(X[:,0], X[:,1], c=y)
plt.title('Original data')
plt.show()

# K-Means clustering
kmeans = KMeans(n_clusters=5)
kmeans_labels = kmeans.fit_predict(X)

# Plot the results of K-Means clustering
plt.scatter(X[:,0], X[:,1], c=kmeans_labels)
plt.title('K-Means Clustering')
plt.show()

# Hierarchical Agglomerative Clustering (HAC)
hac = AgglomerativeClustering(n_clusters=5)
hac_labels = hac.fit_predict(X)

# Plot the results of HAC
plt.scatter(X[:,0], X[:,1], c=hac_labels)
plt.title('Hierarchical Agglomerative Clustering')
plt.show()

# Density-Based Spatial Clustering of Applications with Noise (DBSCAN)
dbscan = DBSCAN(eps=0.5, min_samples=5)
dbscan_labels = dbscan.fit_predict(X)

# Plot the results of DBSCAN
plt.scatter(X[:,0], X[:,1], c=dbscan_labels)
plt.title('DBSCAN Clustering')
plt.show()
