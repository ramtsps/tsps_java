from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import pandas as pd

# Load the dataset
data = pd.read_csv('data.csv')

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data[['x']], data['y'], test_size=0.2)

# Create a decision tree regression model and train it on the training set
model = DecisionTreeRegressor()
model.fit(X_train, y_train)

# Make predictions on the testing set and calculate the mean squared error
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
