from pgmpy.models import BayesianModel
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

# Define the structure of the Bayesian Network
model = BayesianModel([('A', 'B'), ('C', 'B'), ('C', 'D'), ('B', 'E')])

# Define the conditional probability distributions (CPDs)
cpd_A = TabularCPD(variable='A', variable_card=2, values=[[0.5], [0.5]])
cpd_C = TabularCPD(variable='C', variable_card=2, values=[[0.6], [0.4]])
cpd_B = TabularCPD(variable='B', variable_card=2,
                    values=[[0.3, 0.9, 0.7, 0.1], [0.7, 0.1, 0.3, 0.9]],
                    evidence=['A', 'C'], evidence_card=[2, 2])
cpd_D = TabularCPD(variable='D', variable_card=2,
                    values=[[0.2, 0.8], [0.8, 0.2]],
                    evidence=['C'], evidence_card=[2])
cpd_E = TabularCPD(variable='E', variable_card=2,
                    values=[[0.9, 0.1], [0.1, 0.9]],
                    evidence=['B'], evidence_card=[2])

# Add the CPDs to the model
model.add_cpds(cpd_A, cpd_C, cpd_B, cpd_D, cpd_E)

# Check if the model is valid
model.check_model()

# Perform inference using Variable Elimination
infer = VariableElimination(model)

# Calculate the probability of B=1 given evidence A=0, C=1
query = infer.query(variables=['B'], evidence={'A': 0, 'C': 1})
print(query)
