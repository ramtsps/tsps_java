#include<stdio.h>

#define MAX_BLOCKS 25

void main()
{
    int fragment[MAX_BLOCKS], blocks[MAX_BLOCKS], files[MAX_BLOCKS], i, j, num_blocks, num_files, temp, highest=0;
    static int bf[MAX_BLOCKS], ff[MAX_BLOCKS];

    printf("\n\tMemory Management Scheme - Worst Fit");

    printf("\nEnter the number of blocks: ");
    scanf("%d", &num_blocks);

    printf("Enter the number of files: ");
    scanf("%d", &num_files);

    printf("\nEnter the size of the blocks:\n");
    for(i=1; i<=num_blocks; i++)
    {
        printf("Block %d: ", i);
        scanf("%d", &blocks[i]);
    }

    printf("Enter the size of the files:\n");
    for(i=1; i<=num_files; i++)
    {
        printf("File %d: ", i);
        scanf("%d", &files[i]);
    }

    for(i=1; i<=num_files; i++)
    {
        for(j=1; j<=num_blocks; j++)
        {
            if(bf[j] != 1) // If block j is not allocated
            {
                temp = blocks[j] - files[i];

                if(temp >= 0)
                {
                    if(highest < temp)
                    {
                        ff[i] = j;
                        highest = temp;
                    }
                }
            }
        }

        fragment[i] = highest;
        bf[ff[i]] = 1;
        highest = 0;
    }

    printf("\nFile No.\tFile Size\tBlock No.\tBlock Size\tFragment");
    for(i=1; i<=num_files; i++)
    {
        printf("\n%d\t\t%d\t\t%d\t\t%d\t\t%d", i, files[i], ff[i], blocks[ff[i]], fragment[i]);
    }

    getchar(); // Wait for user input before exiting
}
