#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>

int main() {
    int gd=DETECT,gm,count,i,j,mid,cir_x;
    char fname[10][20];
    clrscr();
    initgraph(&gd,&gm,"c:/tc/bgi");
    cleardevice();
    setbkcolor(GREEN);
    printf("Enter number of files: ");
    scanf("%d",&count);
    if(count > 0 && count <= 10) { // added check for valid count
        for(i=0;i<count;i++) {
            cleardevice();
            setbkcolor(GREEN);
            printf("Enter file name %d: ",i+1);
            scanf("%s",fname[i]);
            setfillstyle(1,MAGENTA);
            mid=640/count;
            cir_x=mid/3 + i*mid; // updated cir_x calculation
            bar3d(270,100,370,150,0,0);
            settextstyle(2,0,4);
            settextjustify(1,1);
            outtextxy(320,125,"root directory");
            setcolor(BLUE);
            fillellipse(cir_x,250,30,30);
            outtextxy(cir_x,250,fname[i]);
            if (i > 0) { // added check for drawing line
                line(cir_x, 250, cir_x-mid, 150);
            }
        }
        getch();
        closegraph();
    } else {
        printf("Invalid count. Count should be between 1 and 10.");
    }
    return 0;
}

// Enter number of files: 4
// Enter file name 1: document1
// Enter file name 2: document2
// Enter file name 3: document3
// Enter file name 4: document4

