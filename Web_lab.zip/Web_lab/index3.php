<!DOCTYPE html>
<html>
<head>
	<title>Simple PHP Script Example</title>
</head>
<body>
	<h1>Simple PHP Script Example</h1>
	<?php
		// Define variables
		$name = "John";
		$age = 25;
		$is_student = true;

		// Print variables
		echo "<p>Name: $name</p>";
		echo "<p>Age: $age</p>";
		echo "<p>Is Student: ";
		if ($is_student) {
			echo "Yes</p>";
		} else {
			echo "No</p>";
		}
	?>
</body>
</html>

</html>
