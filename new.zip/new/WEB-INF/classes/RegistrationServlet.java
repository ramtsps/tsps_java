import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegistrationServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String fullName = request.getParameter("full-name");
        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phone-number");
        String address = request.getParameter("address");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String course = request.getParameter("course");
        String semester = request.getParameter("semester");
        String regFees = request.getParameter("registration-fees");

        out.println("<html>");
        out.println("<head><title>Registration Form Data</title></head>");
        out.println("<body>");
        out.println("<h1>Registration Form Data</h1>");
        out.println("<p>Full Name: " + fullName + "</p>");
        out.println("<p>Email: " + email + "</p>");
        out.println("<p>Phone Number: " + phoneNumber + "</p>");
        out.println("<p>Address: " + address + "</p>");
        out.println("<p>Date of Birth: " + dob + "</p>");
        out.println("<p>Gender: " + gender + "</p>");
        out.println("<p>Course: " + course + "</p>");
        out.println("<p>Semester: " + semester + "</p>");
        out.println("<p>Registration Fees: " + regFees + "</p>");
        out.println("</body></html>");
    }
}
